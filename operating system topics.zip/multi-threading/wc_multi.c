#include "wc.h"
#include <time.h>
#include <stdio.h>
#include <sys/wait.h>

typedef struct proc_list {
int pid;
int offset;
int pipes[2];
} proc_list;

#define fork_maximum 300

int main(int argc, char **argv)
{
		long fsize;
		FILE *fp;
		int child_status;
		count_t count, total_count, temp_count;
		struct timespec begin, end;
		
		/* 1st arg: filename */
		if(argc < 2) {
				printf("usage: wc <filname> [# processes] [crash rate]\n");
				return 0;
		}
		int nChildProc = 0;
		/* 2nd arg: number of child processes */
		if (argc > 2) {
				nChildProc = atoi(argv[2]);
				if(nChildProc < 1) nChildProc = 1;
				if(nChildProc > 10) nChildProc = 10;
		}

		proc_list proc[nChildProc];

		/* 3rd (optional) arg: crash rate between 0% and 100%. Each child process has that much chance to crash*/
		if(argc > 3) {
				crashRate = atoi(argv[3]);
				if(crashRate < 0) crashRate = 0;
				if(crashRate > 50) crashRate = 50;
				printf("crashRate is %d\n", crashRate);
		}
		
		printf("no of Child Processes: %d\n", nChildProc);
		printf("crashRate is %d\n", crashRate);

		total_count.linecount = 0;
		total_count.wordcount = 0;
		total_count.charcount = 0;

  // start to measure time
		clock_gettime(CLOCK_REALTIME, &begin);

		fp = fopen(argv[1], "r");

		if(fp == NULL) {
				printf("File open error: %s\n", argv[1]);
				printf("usage: wc <filname>\n");
				return 0;
		}
		
		// get a file size
		fseek(fp, 0L, SEEK_END);
		fsize = ftell(fp);
		fclose(fp);
	
		long offset = (fsize/nChildProc);

        printf("File size ->  %ld \n", fsize);
		printf("Offset value -> %ld \n",offset);

		int no_of_forks = 0;
		int i,pid;
        
		for(i = 0; i < nChildProc; i++) {
		//set pipe;						
		pipe(proc[i].pipes);
		if(no_of_forks++ > fork_maximum) return 0;
      // fork() is called
		pid = fork();
		proc[i].pid = pid;
		if(pid < 0){
			printf("Fork failed.\n");
		} else if(pid == 0){// for child process
			int offset_calc = i*offset;
			fp = fopen(argv[1], "r");
			//calling word_count function passing file, new offset and offset size(for each process)
			count = word_count(fp, offset_calc, offset);
			fclose(fp);
			// send the result to the parent through pipe
            close(proc[i].pipes[0]);
			//writing the each child process message
			write(proc[i].pipes[1],&count,sizeof(count));                   
			close(proc[i].pipes[1]);
			return 0;
		}	    
    }
int flag;
	for(i = 0; i < nChildProc; i++){		
				
		flag=0;
		while(flag!=1){
		// wait for all children
		waitpid(proc[i].pid, &child_status,0);
			// check their exit status
        if(!WIFEXITED(child_status)){
             //goes inside loop whenever child is terminated abnormally
			if(WIFSIGNALED(child_status)){
			//recreation of all the crashed child processes
        if(no_of_forks++ > fork_maximum) return 0;
		pid = fork();
		proc[i].pid=pid;
		if(pid < 0){
		printf(" second Fork failed.\n");
		} else if(pid == 0){
			// for each recreated Child
			fp = fopen(argv[1], "r");
			count = word_count(fp, i*offset, offset);
			fclose(fp);
            close(proc[i].pipes[0]); //parent receives the info of the resukt from the count variable
			write(proc[i].pipes[1],&count,sizeof(count));                   
			close(proc[i].pipes[1]);
			return 0;
			
		}	    
		     }
		     }
		else{	
			// reads the messages from each child process 	
			read(proc[i].pipes[0],&temp_count,sizeof(temp_count));

			// final count of thr number of lines, words, characters, for the entire file
			total_count.linecount += temp_count.linecount;
            total_count.wordcount += temp_count.wordcount;
            total_count.charcount += temp_count.charcount;
			close(proc[i].pipes[0]);
			//closing the pipe
			close(proc[i].pipes[1]);
		    flag =1;
            //end mechanism
			} 	
								 		   
		}
		}


		clock_gettime(CLOCK_REALTIME, &end);
		long seconds = end.tv_sec - begin.tv_sec;
		long nanoseconds = end.tv_nsec - begin.tv_nsec;
		double elapsed = seconds + nanoseconds*1e-9;

		printf("\n------------------%s------------------\n", argv[1]);
		printf("count of Lines -> %d \n", total_count.linecount);
		printf("count of Words -> %d \n", total_count.wordcount);
		printf("count of Characters -> %d \n", total_count.charcount);
		printf("-------------- Took %.3f seconds ----------\n", elapsed);

		return(0);
}