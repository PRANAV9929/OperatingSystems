#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "API.h"
Inode inode[MAX_INODE];
int current_dir_block;
int file_cat(char *name)
{
		int inodeNum, i, size;
		char buf[512];
		char * str;
		inodeNum = search_cur_dir(name);
		size = inode[inodeNum].size;
		if(inodeNum < 0)
		{
				printf("cat error: unable to find file\n");
				return -1;
		}
		if(inode[inodeNum].type == directory)
		{
				printf("cat error: cannot read directory\n");
				return -1;
		}
		str = (char *) malloc( sizeof(char) * (size+1) );
		str[ size ] = '\0';

		for( i = 0; i < inode[inodeNum].blockCount; i++ ){
				int block;
				block = inode[inodeNum].directBlock[i];

				read_disk_block( block, buf );

				if( size >= BLOCK_SIZE )
				{
						memcpy( str+i*BLOCK_SIZE, buf, BLOCK_SIZE );
						size -= BLOCK_SIZE;
				}
				else
				{
						memcpy( str+i*BLOCK_SIZE, buf, size );
				}
		}
		printf("%s\n", str);
		free(str);	
		return 0;
}

int file_remove(char *name)
{
		int i;int k=0;

		
		int inodeNum = search_cur_dir(name); 
		if(inodeNum < 0) {
						printf("File remove has been failed:  %s does not exist.\n", name);
						return -1;
				}
		if(inode[inodeNum].type == directory)
				{
						printf("File remove error occured: cannot remove directory\n");
						return -1;
				}
		current_dir_block=inode[inodeNum].directBlock[0];
		if(inode[inodeNum].linkCount == 1)
				{
				int numBlock = inode[inodeNum].blockCount;
				for(i = 0; i < numBlock; i++)
						{
								int block = inode[inodeNum].directBlock[i];
								free_block(block);
							
						}
			
					free_inode(inodeNum);	
					}
					else
					{

					printf("Data not deleted: hard_links exist \n");
					inode[inodeNum].linkCount--;
					}

				printf("Removed File: %s inode %d \n", name,inodeNum);

				for(i = 0; i < curDir.numEntry; i++)
						{
								if(command(name, curDir.dentry[i].name)) 
								{k=i;break;											
				}
				}
				for(i = k; i < curDir.numEntry; i++)
						{								curDir.dentry[i]=curDir.dentry[i+1];									
						}

				curDir.numEntry--;		
		write_disk_block( current_dir_block,(char*)&curDir);
		return 0;	
}

int hard_link(char *src, char *dest)
{
				int i;

		
		int inodeNum = search_cur_dir(src); 
		if(inodeNum < 0) {
				printf("hard_link create failed:  %s file does not exist.\n", src);
				return -1;
		}

		if(curDir.numEntry + 1 > MAX_DIR_ENTRY) {
				printf("hard_link create failed: directory is full!\n");
				return -1;
		}
		
		inode[inodeNum].linkCount++;
char*  name=dest;
		strncpy(curDir.dentry[curDir.numEntry].name, name, strlen(name));
		curDir.dentry[curDir.numEntry].name[strlen(name)] = '\0';
		curDir.dentry[curDir.numEntry].inode = inodeNum;
		printf("curdir %s, name %s\n", curDir.dentry[curDir.numEntry].name, name);
		curDir.numEntry++;
		printf("hard_link created: %s, inode %d\n", name, inodeNum);

		return 0;
}

int file_copy(char *src, char *dest)
{
		int block, numBlock, i, inodeNum, inDest ;
		char *str;
		char buf[512];
		
		printf("File copy is started exit: from %s to %s\n", src, dest);
		inodeNum = search_cur_dir(src); 
		inDest=search_cur_dir(dest);
		printf("\n%d\n", &inodeNum);
		if(inodeNum < 0) {
				printf("File Copy create has been failed:  src %s file does not exists.\n", src);
				return -1;
		}

		if(inDest >= 0) {
				printf("File Copy  create has been failed:  %s destination file already exists.\n", src);
				return -1;
		}

		if(curDir.numEntry + 1 > MAX_DIR_ENTRY) {
				printf("File Copy  create has been failed: directory is full!\n");
				return -1;
		}



		if(superBlock.freeInodeCount < 1) {
				printf("File create failed: inode is full!\n");
				return -1;
		}
		Inode targetInode = read_inode(inodeNum);
		int size= targetInode.size;
		numBlock = size / BLOCK_SIZE;
		if(size % BLOCK_SIZE > 0) numBlock++;

		if(size > 7680) {
				if(numBlock+1 > superBlock.freeBlockCount)
				{
						printf("File create failed: data block is full!\n");
						return -1;
				}
		} else {
				if(numBlock > superBlock.freeBlockCount) {
						printf("File create failed: data block is full!\n");
						return -1;
				}
		}


		inDest = get_inode();
		if(inDest < 0) {
				printf("File_create error: not enough inode.\n");
				return -1;
		}
		
		Inode newInode;

		newInode.type = file;
		newInode.size = size;
		newInode.blockCount = numBlock;
		newInode.linkCount = 1;

		// add a new file into the current directory entry
		strncpy(curDir.dentry[curDir.numEntry].name, dest, strlen(dest));
		curDir.dentry[curDir.numEntry].name[strlen(dest)] = '\0';
		curDir.dentry[curDir.numEntry].inode = inDest;
		curDir.numEntry++;

		str = (char *) malloc( sizeof(char) * (size+1) );
		str[ size ] = '\0';

		for( i = 0; i < inode[inodeNum].blockCount; i++ ){
				int block;
				block = inode[inodeNum].directBlock[i];

				read_disk_block( block, buf );

				if( size >= BLOCK_SIZE )
				{
						memcpy( str+i*BLOCK_SIZE, buf, BLOCK_SIZE );
						size -= BLOCK_SIZE;
				}
				else
				{
						memcpy( str+i*BLOCK_SIZE, buf, size );
				}
		}


		// get data blocks
		for(i = 0; i < 15; i++)
		{
				if (i >= numBlock) break;
				block = get_block();
				if(block == -1) {
						printf("File_create error: get_block failed\n");
						return -1;
				}
				//set direct block
				newInode.directBlock[i] = block;
				write_disk_block(block, str+(i*BLOCK_SIZE));
		}

		if(size > 7680) {
				// get an indirect block
				block = get_block();
				if(block == -1) {
						printf("File_create error: get_block failed\n");
						return -1;
				}

				newInode.indirectBlock = block;
				int indirectBlockMap[128];

				for(i = 15; i < numBlock; i++)
				{
						block = get_block();
						if(block == -1) {
								printf("File_create error: get_block failed\n");
								return -1;
						}
						//set direct block
						indirectBlockMap[i-15] = block;
						write_disk_block(block, str+(i*BLOCK_SIZE));
				}
				write_disk_block(newInode.indirectBlock, (char*)indirectBlockMap);
		}

		write_inode(inDest, newInode);
		printf("File Copied. from name: %s to dest: %s,\n", src, dest);

		return 0;
}


/* =============================================================*/

int file_create(char *name, int size)
{
		int i;
		int block, inodeNum, numBlock;

		if(size <= 0 || size > 73216){
				printf("File create failed: file size error\n");
				return -1;
		}

		inodeNum = search_cur_dir(name); 
		if(inodeNum >= 0) {
				printf("File create failed:  %s exist.\n", name);
				return -1;
		}

		if(curDir.numEntry + 1 > MAX_DIR_ENTRY) {
				printf("File create failed: directory is full!\n");
				return -1;
		}

		if(superBlock.freeInodeCount < 1) {
				printf("File create failed: inode is full!\n");
				return -1;
		}

		numBlock = size / BLOCK_SIZE;
		if(size % BLOCK_SIZE > 0) numBlock++;

		if(size > 7680) {
				if(numBlock+1 > superBlock.freeBlockCount)
				{
						printf("File create failed: data block is full!\n");
						return -1;
				}
		} else {
				if(numBlock > superBlock.freeBlockCount) {
						printf("File create failed: data block is full!\n");
						return -1;
				}
		}

		char *tmp = (char*) malloc(sizeof(int) * size+1);

		rand_string(tmp, size);
		printf("File contents:\n%s\n", tmp);

		// get inode and fill it
		inodeNum = get_inode();
		if(inodeNum < 0) {
				printf("File_create error: not enough inode.\n");
				return -1;
		}
		
		Inode newInode;

		newInode.type = file;
		newInode.size = size;
		newInode.blockCount = numBlock;
		newInode.linkCount = 1;

		// add a new file into the current directory entry
		strncpy(curDir.dentry[curDir.numEntry].name, name, strlen(name));
		curDir.dentry[curDir.numEntry].name[strlen(name)] = '\0';
		curDir.dentry[curDir.numEntry].inode = inodeNum;
		curDir.numEntry++;

		// get data blocks
		for(i = 0; i < 15; i++)
		{
				if (i >= numBlock) break;
				block = get_block();
				if(block == -1) {
						printf("File_create error: get_block failed\n");
						return -1;
				}
				//set direct block
				newInode.directBlock[i] = block;

				write_disk_block(block, tmp+(i*BLOCK_SIZE));
		}

		if(size > 7680) {
				// get an indirect block
				block = get_block();
				if(block == -1) {
						printf("File_create error: get_block failed\n");
						return -1;
				}

				newInode.indirectBlock = block;
				int indirectBlockMap[128];

				for(i = 15; i < numBlock; i++)
				{
						block = get_block();
						if(block == -1) {
								printf("File_create error: get_block failed\n");
								return -1;
						}
						//set direct block
						indirectBlockMap[i-15] = block;
						write_disk_block(block, tmp+(i*BLOCK_SIZE));
				}
				write_disk_block(newInode.indirectBlock, (char*)indirectBlockMap);
		}

		write_inode(inodeNum, newInode);
		printf("File created. name: %s, inode: %d, size: %d\n", name, inodeNum, size);

		free(tmp);
		return 0;
}

int file_stat(char *name)
{
		char timebuf[28];
		Inode targetInode;
		int inodeNum;
		
		inodeNum = search_cur_dir(name);
		if(inodeNum < 0) {
				printf("file cat error: file does not exist.\n");
				return -1;
		}
		
		targetInode = read_inode(inodeNum);
		printf("Inode = %d\n", inodeNum);
		if(targetInode.type == file) printf("type = file\n");
		else printf("type = directory\n");
		printf("size = %d\n", targetInode.size);
		printf("linkCount = %d\n", targetInode.linkCount);
		printf("num of block = %d\n", targetInode.blockCount);
}


