#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "API.h"
int dir_blck;
Inode inode[MAX_INODE];

int dir_make(char* name)
{
		int inodeNum = search_cur_dir(name); 
		if(inodeNum >= 0) {
				printf("Directory creation has been failed:  %s exist.\n", name);
				return -1;
		}

		if(curDir.numEntry + 1 > MAX_DIR_ENTRY) {
				printf("Directory creation has been  failed : it is full!\n");
				return -1;
		}

		if(1> superBlock.freeBlockCount) {
				printf("Directory creation has been  failed : data block is full!\n");
				return -1;
		}

		if(superBlock.freeInodeCount < 1) {
				printf("Directory creation has been failed: inode is full!\n");
				return -1;
		}
				int dirInode = get_inode();
				int newDirBlock = get_block();
				inode[dirInode].type = directory;
				inode[dirInode].size = 1;
				inode[dirInode].blockCount = 1;
				inode[dirInode].directBlock[0] = newDirBlock;

		strncpy(curDir.dentry[curDir.numEntry].name, name, strlen(name));
		curDir.dentry[curDir.numEntry].name[strlen(name)] = '\0';
		curDir.dentry[curDir.numEntry].inode = dirInode;
		printf("curdir %s, name %s\n", curDir.dentry[curDir.numEntry].name, name);
		curDir.numEntry++;
		write_disk_block( dir_blck,(char*)&curDir);	
	
inode[dirInode].directBlock[0] = newDirBlock;
Dentry newDir;
				newDir.numEntry = 2;
				strncpy(newDir.dentry[0].name, ".", 1);
				newDir.dentry[0].name[1] = '\0';
				newDir.dentry[0].inode = dirInode;
				
				strncpy(newDir.dentry[1].name, "..", 2);
				newDir.dentry[1].name[2] = '\0';
				newDir.dentry[1].inode = curDir.dentry[0].inode;
				write_disk_block(newDirBlock, (char*)&newDir);
		printf("Directory creation is successfull: %s, inode %d\n", name, dirInode);
		return 0;
}

int dir_remove(char *name)
{
		//printf("rmdir is not implemented yet.\n");
		int inodeNum, i, j;
		inodeNum = search_cur_dir(name);

		if(inodeNum < 0)
		{
			printf(" error in removing directory: %s directory does not exist.\n", name);
			return -1;
		}

		if(inode[inodeNum].type != directory)
        {
			printf("eoor in removing directory:%s is not a directory.\n", name);
			return -1;
		}

		for(i=0; i < curDir.numEntry; i++)
		{
			if(strncmp(curDir.dentry[i].name,name,strlen(name))== 0)
			 break;

		}

		for(j = i; j<curDir.numEntry-1; j++)
        {
          curDir.dentry[j] = curDir.dentry[j+1];
        }		
		curDir.numEntry--;

		for(i=0; i<inode[inodeNum].blockCount; i++)
        {
			set_bit(blockMap, inode[inodeNum].directBlock[i],0);
			superBlock.freeBlockCount++;
		}

		set_bit(inodeMap, inodeNum,0);
		superBlock.freeInodeCount++;

		printf("Directory has been Removed successfully. it is : %s",name);
		return 0;
}

int dir_change(char* name)
{
		int inodeNum = search_cur_dir(name); 
		if(inodeNum < 0) {
				printf("Changing of Directory failed:  %s not exist.\n", name);
				return -1;
		}
if(inode[inodeNum].type == file)
		{
				printf(" change of Directory error: type is File\n");
				return -1;
		}	

  dir_blck=inode[inodeNum].directBlock[0];

read_disk_block(dir_blck, (char*)&curDir);	
printf("Changed name of directory is %s inode %d\n",name, inodeNum);
}


/* ===================================================== */

int ls()
{
		int i;
		int inodeNum;
		Inode targetInode;
		for(i = 0; i < curDir.numEntry; i++)
		{
				inodeNum = curDir.dentry[i].inode;
				targetInode = read_inode(inodeNum);
				if(targetInode.type == file) printf("type: file, ");
				else printf("type: dir, ");
				printf("name \"%s\", inode %d, size %d byte\n", curDir.dentry[i].name, curDir.dentry[i].inode, targetInode.size);
		}

		return 0;
}


