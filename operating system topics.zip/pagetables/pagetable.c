#include <stdio.h>
#include <stdlib.h>
#include "vm.h"
#include "API.h"
#include "list.h"

struct Node *head = NULL;
int fifohead = 0;
int lru_queue[257];
int lru_point;
static int  clock_hand[256] = {0};

int fifo()
{
        int start = fifohead;
        fifohead++;
        if(fifohead >= MAX_PFN)
        {
            fifohead = fifohead % MAX_PFN;
        }
        return start;
}

int lru()
{
        int next, min=-1;
        int i;
        for(i=0;i<MAX_PFN;i++)
        {
            if(lru_queue[i] < min || min == -1)
            {
                min = lru_queue[i];
                next = i;
            }   
        }
        return next;
}

int clock()
{
        // Fifo to set clock hand
        int clock_value = fifo();
        while(clock_hand[clock_value] == 1)
        {
            clock_hand[clock_value] = 0;
            clock_value = fifo();
        }
        return clock_value;
}



int find_replacement()
{
        int PFN;
        if(replacementPolicy == ZERO)  PFN = 0;
        else if(replacementPolicy == FIFO)  PFN = fifo();
        else if(replacementPolicy == LRU) PFN = lru();
        else if(replacementPolicy == CLOCK) PFN = clock();

        return PFN;
}

int pagefault_handler(int pid, int VPN, char type)
{
        int PFN;
        // find a free PFN.
        PFN = get_freeframe();
        // no free frame available. find a victim using page replacement. ;
        if(PFN < 0) {
                PFN = find_replacement();
                if(replacementPolicy == LRU) 
                {
                    lru_point++;
                    lru_queue[PFN]=lru_point;
                }   
                /* ---- */
                IPTE swapping = read_IPTE(PFN);
                PTE swap_out_PTE = read_PTE(swapping.pid, swapping.VPN);
                swap_out_PTE.valid = false; //Been swapped out
                write_PTE(swapping.pid, swapping.VPN, swap_out_PTE);
                if (swap_out_PTE.dirty == true)
                {
                    swap_out(swapping.pid, swapping.VPN, PFN);
                }
                swap_in(pid, VPN, PFN);
                IPTE *swapped_in = (IPTE *)malloc(sizeof(IPTE));
                swapped_in->pid = pid;
                swapped_in->VPN = VPN;
                write_IPTE(PFN, *swapped_in);
                swapping = read_IPTE(PFN);

                PTE *pte = (PTE *)malloc(sizeof(PTE));
                pte->valid = true;
                pte->PFN = PFN;
                pte->dirty = (type == 'W') ? true : false;

                write_PTE(pid, VPN, *pte);
        }
        else{
            if(replacementPolicy == LRU) 
            {
                lru_point++;
                lru_queue[PFN]=lru_point;
            }   
            swap_in(pid, VPN, PFN); //bring page from disk to mem frame

            IPTE *swapped_in = (IPTE *)malloc(sizeof(IPTE));
            swapped_in->pid = pid;
            swapped_in->VPN = VPN;
            write_IPTE(PFN, *swapped_in);

            PTE *swap_out_PTE = (PTE *)malloc(sizeof(PTE));
            swap_out_PTE->dirty = (type == 'W') ? true : false;
            swap_out_PTE->PFN = PFN;
            swap_out_PTE->valid = true;
            write_PTE(pid, VPN, *swap_out_PTE);
            if (replacementPolicy == CLOCK)
            {
                clock_hand[PFN] = 1;
            }
        }
        return PFN;
}

int is_page_hit(int pid, int VPN, char type)
{
        /* Read page table entry for (pid, VPN) */
        PTE pte = read_PTE(pid, VPN);

        /* if PTE is valid, it is a page hit. Return physical frame number (PFN) */
        if(pte.valid == true) 
        {
        /* Mark the page dirty, if it is a write request */
                if(type == 'W') 
                {
                        pte.dirty = true;
                        write_PTE(pid, VPN, pte);
                }
        /* Need to take care of a page replacement data structure (LRU, CLOCK) for the page hit*/
        /* ---- */
                int data = pte.PFN;
                /* For the CLOCK Replacement Algorithm */
                if (replacementPolicy == CLOCK)
                {
                    clock_hand[data] = 1;
                }
                return data;
        }
        /* PageFault, if the PTE is invalid. Return -1 */
        return -1;
}

int MMU(int pid, int VPN, char type, bool *hit)
{
        int PFN;

        // hit
        PFN = is_page_hit(pid, VPN, type);
        if(PFN >= 0) {
                stats.hitCount++;
                *hit = true;
                if(replacementPolicy == LRU) 
                {
                    lru_point++;
                    lru_queue[PFN]=lru_point;
                }   
                return PFN; 
        }

        stats.missCount++;
        *hit = false;
                
        // miss -> pagefault
        PFN = pagefault_handler(pid, VPN, type);

        return PFN;
}
