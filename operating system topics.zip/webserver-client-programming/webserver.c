#include <stdio.h>
#include <arpa/inet.h>
#include "webserver.h"
#include <stdlib.h>
#include <semaphore.h>
#include <pthread.h>
#define MAX_REQUEST 100

int port, numThread;
int buffer_y[100];
int counter_y = 0;
int start_y = 0;
sem_t sem_empty, sem_full;
pthread_mutex_t mutex;

struct threadpool
{
	int total_y;
	int count_y;
	int Jobdone_y;
	int threads[100];

} thread_p;

void *listener()
{
	int r;
	struct sockaddr_in sin;
	struct sockaddr_in peer;
	int peer_len = sizeof(peer);
	int sock;

	sock = socket(AF_INET, SOCK_STREAM, 0);
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = htons(port);
	r = bind(sock, (struct sockaddr *)&sin, sizeof(sin));
	if (r < 0)
	{
		perror("Error binding socket:");
		return;
	}

	r = listen(sock, 5);
	if (r < 0)
	{
		perror("Error listening socket:");
		return;
	}

	printf("HTTP server listening on port %d\n", port);

	while (1)
	{

		int j;
		j = accept(sock, NULL, NULL);
		if (j < 0)
			break;
		// producer

		sem_wait(&sem_empty);
		pthread_mutex_lock(&mutex);
		buffer_y[counter_y] = j;

		counter_y += 1;
		if (counter_y == 100)
			counter_y = 0;
		pthread_mutex_unlock(&mutex);
		sem_post(&sem_full);
	}
	close(sock);
}

void *stask()
{
	pthread_mutex_lock(&mutex);
	thread_p.threads[thread_p.count_y] = getpid();
	thread_p.count_y = thread_p.count_y + 1;
	if (thread_p.count_y == 100)
		thread_p.count_y = 0;
	pthread_mutex_unlock(&mutex);
	while (1)
	{
		sem_wait(&sem_full);
		pthread_mutex_lock(&mutex);
		// consumer
		int y = buffer_y[start_y];
		start_y += 1;
		if (start_y == 100)
			start_y = 0;
		thread_p.Jobdone_y++;
		pthread_mutex_unlock(&mutex);
		process(y);
		sem_post(&sem_empty);
	}
}

void thread_control()
{
	int v = 0;
	int status_y;
	pthread_t yid[numThread];
	pthread_t y_t;

	status_y = pthread_create(&(y_t), NULL, &listener, NULL);

	while (v < numThread)
	{
		status_y = pthread_create(&(yid[v]), NULL, &stask, NULL);

		if (status_y != 0)
			printf("\nThread cannot be created :[%s]", strerror(status_y));
		v++;
	}

	// Handling of the crashed client threads
	while (1)
	{
		for (v = 0; v < numThread; v++)
		{

			if (pthread_tryjoin_np(yid[v], NULL) == 0)
			{
				status_y = pthread_create(&(yid[v]), NULL, &stask, NULL);

				if (status_y != 0)
					printf("\nThread cannot be created :[%s]", strerror(status_y));
			}
		}
	}
	pthread_join(y_t, NULL);
}

int main(int argc, char *argv[])
{
	int emp_y = sem_init(&sem_empty, 0, 100);
	int full_y = sem_init(&sem_full, 0, 0);

	if (argc > 4 || atoi(argv[1]) < 2000 || atoi(argv[1]) > 50000)
	{
		fprintf(stderr, "./webserver_multi PORT(2001 ~ 49999) #_of_threads\n");
		return 0;
	}
	if (argc > 3)
	{
		CRASH = atoi(argv[3]);
		if (CRASH < 0)
			CRASH = 0;
		if (CRASH > 50)
			CRASH = 50;
		printf("CRASH RATE: %d\n", CRASH);
	}
	port = atoi(argv[1]);
	numThread = atoi(argv[2]);
	thread_p.total_y = numThread;
	thread_p.count_y = 0;
	thread_control();
	pthread_mutex_destroy(&mutex);
	sem_destroy(&sem_full);
	sem_destroy(&sem_empty);

	return 0;
}